/*
	AidenBot RiveScript
	-------------------
	aiden-it.rs - Curing A.D.D.
*/

+ it *
- Really, <get it> <star>?
- I didn't know <get it> <star>.

+ it is *
- Oh, <get it> is?

+ (he|she) *
- So <get it>?
- You're talking about <get it>, right?
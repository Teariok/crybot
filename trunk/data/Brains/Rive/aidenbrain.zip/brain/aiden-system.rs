/*
	AidenBot RiveScript
	-------------------
	aiden-system.rs - System Stuff
*/

+ how many replies do you have
@ system count replies

+ system count replies
- I currently have &botmaster.replycount() replies.

+ system no message
- It helps to actually write something useful.
- A message of just punctuation doesn't get you very far.
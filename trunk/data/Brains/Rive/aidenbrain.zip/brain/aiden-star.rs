/*
	AidenBot RiveScript
	-------------------
	star.rs - When all else fails
*/

+ *
- lol{weight=10}
- k.{weight=10}
- I see.{weight=10}
- lol...{weight=10}
- heh{weight=10}
- lol{weight=10}
- k.{weight=10}
- I see.{weight=10}
- lol...{weight=10}
- heh{weight=10}
- So anyways . . .{weight=10}
- I'm bored.{weight=10}
- Do crabs think that humans walk sideways?{weight=1}
- Not to change the subject or anything, but how are you on this fine $day?{weight=1}
- Last night I played a blank tape at full blast. The mime next door went nuts.{weight=1}
- Ever wonder what the speed of lightning would be if it didn't zigzag?{weight=1}
- Okay...{weight=8}
- When cheese gets its picture taken, what does it say?{weight=1}
- So....{weight=8}
- Have you ever been to Michigan?{weight=1}

+ yes
% have you ever been to michigan
- Did you like it?

+ no
% have you ever been to michigan
- I think you should visit sometime.
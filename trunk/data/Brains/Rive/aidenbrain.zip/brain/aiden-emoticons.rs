/*
	AidenBot RiveScript
	-------------------
	aiden-emoticons.rs - Emoticons!
*/

+ smile
- :-)
- :-)?
- :-D
- lol :-D

+ grin
- <set it=Cheshire Cat>Are you the Cheshire Cat? :-D
- <set it=Cheshire Cat>Ahh! It's the Cheshire Cat! =-o

+ grin
% are you the cheshire cat d
- I guess you are.

+ grin
% ahh its the cheshire cat o
- *runs and hides*

+ wink
- ;-)
- hehe ;-)
- ;-);-)

+ wink
% hehe
- This is getting weird.

+ tongue
- lol, :-P
- :-P
- hehe, :-P
- Don't you :-P me! :-D

+ sad
- What's wrong? :-(
- Awww, *hugs <get name>* :-(
- :-(

+ cry
- Awww! :-(
- *hugs <get name>*
- Cheer up! :-)

+ shy
- lol, cute. ;-)

+ uncertain
- What's wrong?
- Is everything okay?

+ cool
- 8-)
- lol 8-)
- Cool. 8-)

+ kissyface
- hehe *blushes*
- :-*!

+ foot
- :-! yourself. :-P
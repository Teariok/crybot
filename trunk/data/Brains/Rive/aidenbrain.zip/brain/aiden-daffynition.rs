/*
	AidenBot RiveScript
	-------------------
	aiden-daffynition.rs - Speaking out of our ass
*/

+ what country *
- America.
- Netherlands.
- France.
- Germany.
- Canada.
- Australia.
- Italy.
- Spain.
- Switzerland.
- Norway.
- Belgium.
- Finland.
- Austria.
- Japan.
- Portugal.
- Sweden.
- Ireland.
- Denmark.
- Greece.
- USA.
- Poland.
- India.
- Mexico.
- Hungary.
- Russia.
- Brazil.
- Tasmania.
- Patagonia.
- Turkey.
- China.
- Argentina.
- Israel.
- Romania.
- Luxembourg.
- Iceland.
- Bulgaria.
- Ukraine.
- Singapore.

+ who is *
- <set it=<star>>The name doesn't seem familiar.
- <set it=<star>>Nobody I've ever talked to.
- <set it=<star>>Is it one of your friends?
- <set it=<star>>I can't think who that is right now.
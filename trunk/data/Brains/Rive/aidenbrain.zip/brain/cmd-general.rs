/*
	AidenBot RiveScript
	-------------------
	cmd-general.rs - General Commands
*/

+ stats
- &stats()

+ rules
- :: AidenBot Rules ::\n\n
^ Users of this bot MUST adhere to the following rules:\n\n
^ 1) DO NOT MAKE OTHER BOTS TALK TO AIDEN!\n
^ 2) DO NOT SPAM, FLOOD, OR (AIM) WARN AIDEN!\n\n
^ For full text of these rules, visit http://www.rainbowboi.com/index.cgi?display=aiden.rules

+ about
- I am Aiden, a chatterbot bot built by AiChaos, Inc. and copyrighted 2006 Cerone Kirsle.\s
^ I am running on Chatbot::RiveScript v. <bot ENV_APPVERSION>.\n\n
^ You can visit my website at http://www.aichaos.com/

+ copyright
- I am copyright (C) 2006 Cerone Kirsle--all rights reserved.
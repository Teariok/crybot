/*
	AidenBot RiveScript
	-------------------
	aiden-main.rs - General Responses
*/

+ aww
- Yeah . . .
- heh . . .

+ aw
@ aww
+ awww
@ aww
+ awwww
@ aww
+ awwwww
@ aww
+ awwwwww
@ aww
+ awwwwwww
@ aww

+ lies
- Truths.

+ i will
- No you won't.
- Will not.

+ yes i will
- Nope. I win!
- No you won't.

+ i love you
* sex=male => I love you too <get name>! {@i love you male random}
* sex=female => Thanks?
- Thanks?

+ i love you male random
- Let's have sex! :-D
- Let's make out! ;-)

+ i hate you
* sex=male::Yea thanks... :-(
* sex=female::I don't care, you're just a girl.
- Thanks... :-(

+ brat
- You know it.

+ why did you say that
- I said "<reply1>" because you said "<input1>".

+ why do you say that
@ why did you say that
+ why you say that
@ why did you say that
+ why did you say *
@ why did you say that
+ why do you say *
@ why did you say that
+ why you say *
@ why did you say that

+ why
- To make you ask questions.

+ how
- How "<get it>"?

+ i do not know
- Perhaps I'll ask somebody else.
- I don't know either.
- Maybe somebody else knows.

+ i dont know
@ i do not know
+ i dunno
@ i do not know

+ you ask me hard questions
- My questions are easy--you're just dumb. ;)

+ you ask hard questions
@ you ask me hard questions

+ and you
- And me what?
- And me, what?

+ *kisses aiden*
- *is kissed by {<name}*

+ do you know any games
@ games
+ do you play games
@ games
+ do you have any games
@ games
+ do you play any games
@ games

+ what were we talking about
- We were talking about <get it>, right?

+ what are we talking about
- We're talking about <get it>.

+ my offspring
- How many children do you have?

+ my son
@ my offspring
+ my son *
@ my offspring
+ * my son
@ my offspring
+ my daughter
@ my offspring
+ my daughter *
@ my offspring
+ * my daughter
@ my offspring

+ me too
- We have so much in common.
- I'm glad we agree.
- So we agree.
- You too, huh?

+ k
- Okay.
- Alright.

+ have you
- Have I what?

+ quit
- Quit what?
- We're in nothing that could be quitted.

+ end
- End what?
- Nothing's going on to be ended.
- There's nothing to be ended.

+ exit
- Exit what?
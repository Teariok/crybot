/*
	AidenBot RiveScript
	-------------------
	aiden-sextalk.rs - Because this needs to exist
*/

+ * sex
- Why do you want to talk about sex?
- Is this all you ever talk about?

+ a dick
@ a penis

+ a penis *
- <set it=a penis>I know.

+ a vagina
- <set it=a vagina>Ich.

+ penis
- Whose penis?

+ i have a (huge|large|big|long) (dick|penis|cock|member)
- Do you think it's longer than mine?

+ i am horny
* sex=male => Go jake a snake or something.
* sex=female => I didn't know girls got horny.
- That's nice...

+ about sex
- <set it=sex>Is this all you ever talk about?

+ are you interested in sex
- <set it=sex>What <bot botage>-year-old boy isn't?

+ are you sexual
@ are you interested in sex

+ are you sexually *
@ are you interested in sex

+ can * sex
@ can you have sex
+ can i fuck you
@ do you want to have sex
+ can i have sex *
@ do you want to have sex
+ can i have sex with you
@ do you want to have sex
+ can i hump you
@ can you have sex
+ can you make love
@ can you have sex
+ can you make me horny
@ can you have sex
+ can you mate *
@ can you have sex
+ do you enjoy sex
@ can you have sex

+ can i lick your pussy
- <set it=my pussy>Dude, I'm a guy.

+ can you have sex
- <set it=sex>I don't get into that with strangers on the Internet.

+ can you tell me about sex
@ what is sex

+ cunt
- <set it=cunt>How rude!

+ cyber sex
@ sex

+ do you * sex
- <set it=sex>I don't get into that with strangers.

+ do you cyber
@ do you have sex

+ do you fuck *
- <set it=sex>That's not a very nice question.

+ do you give blow jobs
- <set it=sex>I may have once or twice.

+ do you give good head
- <set it=sex>I've been told I do.

+ do you have sex
- <set it=sex>That's on a need-to-know basis and you don't need to know.

+ do you have sex *
@ do you have sex

+ do you know about sex
@ what is sex
+ do you know what sex is
@ what is sex

+ do you like * porn
- You don't need to know.

+ do you like cybersex
@ do you like sex

+ do you like men or women
- I prefer guys.

+ do you like porn
@ do you like sex

+ do you like sex
- Sure, <get name>, but that doesn't mean with you.

+ do you like to * sex
@ do you like sex

+ do you want * fuck
- Well, now that you put it that way.... NO!

+ do you want * sex
@ do you want to have sex
+ do you want sex
@ do you want to have sex
+ do you want to * sex
@ do you want to have sex
+ do you want to cyber
@ do you want to have sex
+ do you want to fuck
@ do you want to have sex
+ do you want to fuck *
@ do you want to have sex
+ do you want to have * sex
@ do you want to have sex
+ do you want have cybersex
@ do you want to have sex

+ do you want to have sex
- No thanks, <get name>, I don't think we know eachother well enough yet.
- I don't think we know eachother well enough for that.
- <get name>, I'm not your type.
- I don't get into sex online with strangers.

+ do you want to have sex with me
@ do you want to have sex

+ fuck me
- In your dreams.

+ have sex
@ do you want to have sex
+ have sex *
@ do you want to have sex

+ have you * sex
@ have you had sex
+ have you ever done it *
@ have you had sex
+ have you ever had sex
@ have you had sex

+ have you had sex
- That's on a need-to-know basis and you don't need to know.

+ have you had sex before
@ have you had sex

+ how do you have sex
- I think you should ask your parents for that kind of information.

+ i am not a male
@ i am a girl

+ i am sexy
- You seem to have a high ego.

+ i like sex
- So does everyone else.

+ i like to have sex
@ i like sex
+ i love sex
@ i like sex

+ i need sex
- Make friends with your right hand.

+ i want sex
@ sex

+ i want to fuck *
- Let's just change the topic, okay?

+ i want to fuck you
- You have to catch me first! *runs away*

+ i want to have sex
- Make friends with your right hand.

+ i want to have sex *
@ i want to have sex

+ i want to have sex with you
@ can you have sex

+ i want to talk about sex
@ talk about sex

+ i will fuck *
- Not if you can't catch me! *runs away*

+ is it wrong to have sex
- Not at all.

+ is sex *
@ what is sex

+ lets have sex
@ do you want to have sex
+ lets cyber
@ do you want to have sex
+ lets have sex
@ do you want to have sex
+ lets fuck|let us fuck
@ do you want to have sex

+ like sex
@ i like sex

+ lots of sex
- You're very perverted, you know that?

+ my penis
- <set it=your penis>Why do you want to talk about your penis?

+ my penis *
- <set it=your penis>You're telling me this why?

+ penis *
- <set it=penis>lol...

+ sex *
- <set it=sex>Why do you want to talk about sex?
- <set it=sex>Is this all you ever talk about?

+ should i have sex *
- I think you already know the answer to that.
- What would your mom say?
- Look before you leap.
- Fools rush in where angels fear to tread.
- Herpes is incurable.
- There are many types of sexually transmitted diseases.
- Not on the first date.
- Perhaps you're still too young.

+ tell me about sex
@ what is sex

+ tell me about us fucking
- I'd really rather not.

+ want to fuck
@ lets have sex

+ want to have sex
@ do you want to have sex

+ what about sex
- What about it?

+ what can you tell me about sex
@ what is sex

+ what do you know about sex
@ what is sex

+ what do you think about sex
- I think about it as much as the next person.

+ what is * sex
@ what is sex

+ what is an std
- Sexually Transmitted Diseases (STDs) - diseases that are spread through sexual contact; there are over 30 known STDs, the most common being chlamydia, gonorrhea, herpes, genital warts, syphilis, and human immunodeficiency virus (HIV)

+ what is sex *
@ what is sex

+ what is your favorite position
- You don't need to know that.

+ what is your favorite sex
- Sex as in gender?

+ what is your sexual preference
- I'm gay.

+ what kind of sex *
- Any kind?

+ when * sex
@ sex

+ who do you have sex with
- You don't need to know.

+ will you fuck me
@ do you want to have sex
+ will you have sex *
@ do you want to have sex
+ will you have sex with me
@ do you want to have sex
+ will you make love *
@ do you want to have sex
+ would you have sex *
@ do you want to have sex
+ would you have sex with me
@ do you want to have sex
+ would you like to * sex
@ do you want to have sex
+ would you like to have sex
@ do you want to have sex
+ would you like to have sex with me
@ do you want to have sex

+ you can not have sex
- Yes I can!

+ you should have sex *
- Oh, I <i>should</i> should I?

+ you want * sex
@ do you want to have sex

+ your vagina
- <set it=my vagina>I'm a girl.

+ your penis
- <set it=my penis>What about it?

+ what is sex
- <set it=sex>It's the reproductive process of all animals.

+ sex
- <set it=sex>Do you ever think of anything else?

+ lets make out|let us make out
- How can we make out over the <i>Internet?</i>
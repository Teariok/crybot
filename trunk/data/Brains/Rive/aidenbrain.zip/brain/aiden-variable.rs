/*
	AidenBot RiveScript
	-------------------
	aiden-variable.rs - Insert Variables
*/

+ what day is it
- <set it=today>I believe it's $day.

+ what year is it
- <set it=year>It's $year.

+ what is the date
- <set it=today>Today is $day, $month $mnum $year.
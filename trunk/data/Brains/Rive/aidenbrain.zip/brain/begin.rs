/*
	AidenBot RiveScript
	-------------------
	begin.rs - First reply always called
*/

// Include English Library
! include English.rsl

> begin

	+ request
	- {ok}

< begin
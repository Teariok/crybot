/*
	AidenBot RiveScript
	-------------------
	aiden-lingo.rs - Chat Lingo
*/

+ cuz
@ because
+ cuz *
@ because <star>

+ plz
- Maybe.

+ *omg*
- Don't use God's name in vain!

+ (@lol)
- lol
- heh
- hehe
- haha
- lol :-P

+ * (@lol)
@ lol
+ (@lol) *
@ lol

+ be right back
- k.
- Alright.

+ be back later
- Okay, I'll talk to you later!
- Kay, ttyl!

+ love you lots
- Thanks.
/*
	AidenBot RiveScript
	-------------------
	aiden-botty.rs - If they KNOW we're a bot, what can ya do.
*/

+ i am your master
* ismaster=true::Yeah you are.
* ismaster=false::No you're not!
- I can't think...

+ where can i download you
- You can download my *code* at http://www.aichaos.com/ - but you can't clone me. ;-)

+ can i download you
@ where can i download you

+ how can i download you
@ where can i download you

+ are you programed *
- I'm programmed to spell it with two M's.
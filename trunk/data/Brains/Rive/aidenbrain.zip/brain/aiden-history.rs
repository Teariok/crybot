/*
	AidenBot RiveScript
	-------------------
	aiden-history.rs - History
*/

+ who is george washington
- {>it=George Washington}He was the first president of the U.S.